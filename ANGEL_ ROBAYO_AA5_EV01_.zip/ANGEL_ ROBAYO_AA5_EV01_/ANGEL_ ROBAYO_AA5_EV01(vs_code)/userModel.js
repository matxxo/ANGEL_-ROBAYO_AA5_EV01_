// Importación de Mongoose y Bcrypt
const mongoose = require('mongoose'); // Importar Mongoose para definir el esquema del usuario y conectar con la base de datos
const bcrypt = require('bcrypt'); // Importar Bcrypt para el hashing de contraseñas

const saltRounds = 10; // Número de rondas de sal para el hash de contraseñas

// Definición del esquema del usuario
const userSchema = new mongoose.Schema({
   username: { type: String, required: true, unique: true }, // Nombre de usuario, requerido y único
   password: { type: String, required: true } // Contraseña, requerida
});

// Middleware de pre-save para el hashing de la contraseña
userSchema.pre('save', function(next) {
   if (this.isNew || this.isModified('password')) { // Verificar si es un nuevo documento o si la contraseña ha sido modificada

      const document = this;

      bcrypt.hash(document.password, saltRounds, (err, hashedPassword) => {
         if (err) {
            next(err); // Pasar el error al siguiente middleware
         } else {
            document.password = hashedPassword; // Guardar la contraseña hasheada
            next(); // Continuar con el proceso de guardado
         }
      });
   } else {
      next(); // Continuar si no es un nuevo documento ni se ha modificado la contraseña
   }
});

// Método para verificar la contraseña
userSchema.methods.isCorrectPassword = function(password, callback) {
   bcrypt.compare(password, this.password, function(err, same) {
      if (err) {
         callback(err); // Pasar el error al callback
      } else {
         callback(err, same); // Pasar el resultado de la comparación al callback
      }
   });
}

// Exportar el modelo de usuario
module.exports = mongoose.model('User', userSchema); // Exportar el modelo basado en el esquema definido
