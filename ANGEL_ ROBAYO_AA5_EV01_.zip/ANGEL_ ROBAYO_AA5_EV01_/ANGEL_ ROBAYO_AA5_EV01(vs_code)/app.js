const express = require('express'); // Importar Express
const path = require('path'); // Importar Path para manejar rutas de archivos
const bodyParser = require('body-parser'); // Importar Body-Parser para manejar datos de solicitud
const app = express(); // Crear una instancia de Express

const bcrypt = require('bcrypt'); // Importar Bcrypt para el hashing de contraseñas
const mongoose = require('mongoose'); // Importar Mongoose para interactuar con MongoDB
const User = require('./userModel') // Importar el modelo de usuario

// Configuración del middleware
app.use(bodyParser.json()); // Middleware para parsear JSON
app.use(bodyParser.urlencoded({ extended: false })); // Middleware para parsear datos URL-encoded

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public'))); // Servir archivos estáticos desde el directorio 'public'

// Configuración de la conexión a MongoDB
const mongo_url = 'mongodb://localhost:27017/user_password'; // URL de conexión a la base de datos MongoDB

mongoose.connect(mongo_url)
.then(() => {
  console.log(`Successfully connected to ${mongo_url}`); // Mensaje de éxito en la conexión
})
.catch((err) => {
  console.error('Error connecting to MongoDB:', err); // Mensaje de error en la conexión
});

// Ruta de registro de usuario
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const user = new User({ username, password });
  try {
    await user.save(); // Usar await para esperar la promesa
    res.status(200).send('USUARIO REGISTRADO'); // Respuesta exitosa
  } catch (err) {
    res.status(500).send('ERROR AL REGISTRAR AL USUARIO'); // Respuesta en caso de error
  }
});

// Ruta de autenticación de usuario
app.post('/authenticate', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Usar await para esperar la promesa de findOne
    const user = await User.findOne({ username });

    if (!user) {
      res.status(500).send('EL USUARIO NO EXISTE'); // Usuario no encontrado
      return;
    }

    // Usar await para esperar la promesa de isCorrectPassword
    user.isCorrectPassword(password, (err, result) => {
      if (err) {
        res.status(500).send('ERROR AL AUTENTICAR'); // Error en la autenticación
      } else if (result) {
        res.status(200).send('USUARIO AUTENTICADO CORRECTAMENTE'); // Autenticación exitosa
      } else {
        res.status(500).send('USUARIO Y/O CONTRASEÑA INCORRECTA'); // Credenciales incorrectas
      }
    });
  } catch (err) {
    res.status(500).send('ERROR AL AUTENTICAR AL USUARIO'); // Respuesta en caso de error
  }
});




// Ruta para obtener todos los usuarios registrados
app.get('/register', async (req, res) => {
  try {
    const users = await User.find(); // Obtener todos los usuarios
    res.json(users); // Enviar todos los usuarios en formato JSON
  } catch (err) {
    res.status(500).send('ERROR AL OBTENER LOS USUARIOS'); // Respuesta en caso de error
  }
});

// Iniciar el servidor
app.listen(3001, () => {
  console.log('Server started on port 3001'); // Mensaje al iniciar el servidor
});

module.exports = app; // Exportar la aplicación
